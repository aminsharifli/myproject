// NaN => Not a Number
// Kupon Sayğacı
let couponCount = 0;
const couponNumber = document.getElementById("coupon-number");
const couponAddButton = document.querySelector(".coupon-add");

if (localStorage.getItem("couponCounter") == null) {
  couponCount = 0;
  couponNumber.innerText = couponCount;
} else {
  couponCount = +localStorage.getItem("couponCounter");
  couponNumber.innerText = couponCount;
}

couponAddButton.addEventListener("click", function () {
  couponCount += 1; // 0 => 1
  couponNumber.innerText = couponCount;

  localStorage.setItem("couponCounter", couponCount);
});
